﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;

/// <summary>
/// 보스 몬스터 (아이템 드롭 지원)
/// </summary>
public class BossMonster : Monster
{
    [Header("보스 전용 설정")]
    [SerializeField] private string bossTitle = "강력한";
    [SerializeField] private bool hasPhases = false;
    [SerializeField] private int[] phaseThresholds;
    [SerializeField] private float[] phaseSpeedMultipliers;
    private int currentPhase = 0;

    [Header("특수 공격")]
    [SerializeField] private bool useSpecialAttack = true;
    [SerializeField] private float specialAttackInterval = 5f;
    [SerializeField] private int specialAttackDamage = 50;
    [SerializeField] private GameObject specialAttackEffect;
    private float lastSpecialAttackTime = 0f;

    [Header("보스 UI")]
    [SerializeField] private GameObject bossHealthBarPrefab;
    private GameObject bossHealthBarInstance;
    private Slider bossHpSlider;
    private TextMeshProUGUI bossNameText;

    [Header("보스 보상")]
    [SerializeField] private int bossGoldMultiplier = 5;
    [SerializeField] private int bossExpMultiplier = 10;

    [Header("보스 확정 드롭")]
    [Tooltip("보스가 100% 드롭하는 아이템들")]
    [SerializeField] private ItemData[] guaranteedDrops;
    [SerializeField] private float guaranteedDropChance = 100f;

    [Header("보스 등장 연출")]
    [SerializeField] private GameObject appearEffect;
    [SerializeField] private AudioClip bossMusic;
    [SerializeField] private string bossWarningMessage = "보스 등장!";

    void Start()
    {
        currentHp = maxHp;
        PlayBossEntrance();
        CreateBossHealthBar();
    }

    void Update()
    {
        base.Update();

        if (hasPhases) CheckPhaseTransition();

        if (useSpecialAttack && Time.time - lastSpecialAttackTime >= specialAttackInterval)
        {
            PerformSpecialAttack();
            lastSpecialAttackTime = Time.time;
        }

        UpdateBossUI();
    }

    private void PlayBossEntrance()
    {
        Debug.Log($"보스 등장: {bossTitle} {monsterName}");
        if (UIManager.Instance != null)
            UIManager.Instance.ShowMessage(bossWarningMessage, Color.red);
        if (appearEffect != null)
            Instantiate(appearEffect, transform.position, Quaternion.identity);
    }

    private void CreateBossHealthBar()
    {
        if (bossHealthBarPrefab == null) return;
        Canvas canvas = FindObjectOfType<Canvas>();
        if (canvas == null) return;

        bossHealthBarInstance = Instantiate(bossHealthBarPrefab, canvas.transform);
        bossHpSlider = bossHealthBarInstance.GetComponentInChildren<Slider>();
        bossNameText = bossHealthBarInstance.GetComponentInChildren<TextMeshProUGUI>();
        if (bossNameText != null)
            bossNameText.text = $"{bossTitle} {monsterName}";
        UpdateBossUI();
    }

    private void UpdateBossUI()
    {
        if (bossHpSlider != null)
            bossHpSlider.value = (float)currentHp / maxHp;
    }

    private void CheckPhaseTransition()
    {
        if (phaseThresholds == null || currentPhase >= phaseThresholds.Length) return;
        float hpPercent = ((float)currentHp / maxHp) * 100f;
        if (hpPercent <= phaseThresholds[currentPhase])
            TransitionToNextPhase();
    }

    private void TransitionToNextPhase()
    {
        currentPhase++;
        Debug.Log($"보스 페이즈 {currentPhase} 돌입!");
        if (UIManager.Instance != null)
            UIManager.Instance.ShowMessage($"페이즈 {currentPhase}!", Color.red);
        if (phaseSpeedMultipliers != null && currentPhase - 1 < phaseSpeedMultipliers.Length)
            SetSpeed(GetSpeed() * phaseSpeedMultipliers[currentPhase - 1]);
        if (appearEffect != null)
            Instantiate(appearEffect, transform.position, Quaternion.identity);
    }

    private void PerformSpecialAttack()
    {
        Collider2D[] targets = Physics2D.OverlapCircleAll(transform.position, 3f);
        foreach (Collider2D target in targets)
        {
            if (target.CompareTag("Player"))
            {
                IHitable hitable = target.GetComponent<IHitable>();
                if (hitable != null)
                    hitable.Hit(specialAttackDamage);
            }
        }
        if (specialAttackEffect != null)
            Instantiate(specialAttackEffect, transform.position, Quaternion.identity);
    }

    /// <summary>
    /// ★ 보스 사망 - base.Die() 호출로 애니메이션 + 풀 반환 처리
    /// </summary>
    protected override void Die()
    {
        Debug.Log($"보스 {monsterName} 처치!");

        // ─── 보스 전용 처리 ───
        if (AchievementSystem.Instance != null)
        {
            AchievementSystem.Instance.UpdateAchievementProgress(AchievementType.KillBoss, monsterName, 1);
            AchievementSystem.Instance.UpdateAchievementProgress(AchievementType.KillBoss, "", 1);
        }

        if (QuestManager.Instance != null)
            QuestManager.Instance.UpdateQuestProgress(QuestType.BossKill, monsterName, 1);

        // 보스 체력바 제거
        if (bossHealthBarInstance != null)
        {
            Destroy(bossHealthBarInstance);
            bossHealthBarInstance = null;
        }

        // 보스 전용 보상
        DropBossReward();

        if (UIManager.Instance != null)
            UIManager.Instance.ShowMessage($"{monsterName} 처치!", Color.yellow);

        // ★ base.Die() 호출 → 애니메이션 + 풀 반환까지 처리!
        base.Die();
    }

    private void DropBossReward()
    {
        int bossGold = GoldDrop * bossGoldMultiplier;
        int bossExp = ExpDrop * bossExpMultiplier;

        if (GameManager.Instance != null)
        {
            GameManager.Instance.AddGold(bossGold);
            GameManager.Instance.AddExp(bossExp);
        }

        if (guaranteedDrops != null && guaranteedDrops.Length > 0)
        {
            foreach (ItemData item in guaranteedDrops)
            {
                if (item != null && Random.Range(0f, 100f) <= guaranteedDropChance)
                {
                    if (InventoryManager.Instance != null)
                    {
                        InventoryManager.Instance.AddItem(item, 1);
                        if (UIManager.Instance != null)
                            UIManager.Instance.ShowMessage($"{item.itemName} 획득!", Color.yellow);
                    }
                }
            }
        }

        if (ItemDropTable != null && ItemDropTable.Length > 0)
            DropItemsFromTable();
    }

    private void DropItemsFromTable()
    {
        if (ItemDropTable == null || InventoryManager.Instance == null) return;

        foreach (ItemDropData dropData in ItemDropTable)
        {
            if (dropData.item == null) continue;
            float boostedChance = Mathf.Min(dropData.dropChance * 1.5f, 100f);
            if (Random.Range(0f, 100f) <= boostedChance)
            {
                int dropAmount = Mathf.CeilToInt(Random.Range(dropData.minAmount, dropData.maxAmount + 1) * 1.5f);
                InventoryManager.Instance.AddItem(dropData.item, dropAmount);
                if (UIManager.Instance != null)
                    UIManager.Instance.ShowMessage($"{dropData.item.itemName} x{dropAmount} 획득!", Color.green);
            }
        }
    }

    public void InitializeBoss(string name, int hp, int atk, float speed, Vector2 direction, string title = "강력한")
    {
        Initialize(name, hp, atk, speed, direction);
        bossTitle = title;
        monsterName = $"{bossTitle} {name}";
    }

    void OnDestroy()
    {
        if (bossHealthBarInstance != null)
            Destroy(bossHealthBarInstance);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, 3f);
    }
}