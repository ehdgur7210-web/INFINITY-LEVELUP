using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MailSlot : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private TextMeshProUGUI titleText;
    [SerializeField] private TextMeshProUGUI dateText;
    [SerializeField] private GameObject unreadBadge;
    [SerializeField] private GameObject rewardBadge;
    [SerializeField] private Button button;

    private Mail mail;
    private System.Action onClickCallback;

    public void Setup(Mail mailData, System.Action onClick)
    {
        mail = mailData;
        onClickCallback = onClick;

        // ����
        if (titleText != null)
        {
            titleText.text = mail.title;
        }

        // ��¥
        if (dateText != null)
        {
            dateText.text = mail.sendDate.ToString("MM/dd");
        }

        // ���� ���� ����
        if (unreadBadge != null)
        {
            unreadBadge.SetActive(!mail.isRead);
        }

        // ���� ����
        if (rewardBadge != null)
        {
            bool hasReward = mail.hasReward && !mail.isRewardClaimed;
            rewardBadge.SetActive(hasReward);
        }

        // ��ư
        if (button != null)
        {
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(() => onClickCallback?.Invoke());
        }
    }
}
