using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// ���� UI �Ŵ���
/// - ���� ��� ǥ��
/// - ���� �� ����
/// - ���� �ڵ� �Է�
/// - ���� ����
/// </summary>
public class MailUI : MonoBehaviour
{
    public static MailUI Instance;

    [Header("���� �г�")]
    [SerializeField] private GameObject mailPanel;          // ��ü ���� �г�

    [Header("���� ���")]
    [SerializeField] private GameObject mailListPanel;      // ���� ��� �г�
    [SerializeField] private Transform mailListContent;     // Scroll View Content
    [SerializeField] private GameObject mailSlotPrefab;     // ���� ���� ������

    [Header("���� ��")]
    [SerializeField] private GameObject mailDetailPanel;    // ���� �� �г�
    [SerializeField] private TextMeshProUGUI detailTitle;   // ����
    [SerializeField] private TextMeshProUGUI detailContent; // ����
    [SerializeField] private TextMeshProUGUI detailDate;    // ��¥
    [SerializeField] private Transform rewardListContent;   // ���� ���
    [SerializeField] private GameObject rewardSlotPrefab;   // ���� ���� ������
    [SerializeField] private Button claimButton;            // ���� ��ư
    [SerializeField] private Button deleteButton;           // ���� ��ư
    [SerializeField] private Button backButton;             // �ڷ� ����

    [Header("���� �Է�")]
    [SerializeField] private GameObject couponPanel;        // ���� �Է� �г�
    [SerializeField] private TMP_InputField couponInput;    // ���� �Է� �ʵ�
    [SerializeField] private Button couponSubmitButton;     // ���� ��ư
    [SerializeField] private Button couponCloseButton;      // �ݱ� ��ư

    [Header("��ư")]
    [SerializeField] private Button openCouponButton;       // ���� �Է� ����
    [SerializeField] private Button closeMailButton;        // ����â �ݱ�
    [SerializeField] private Button claimAllButton;         // ��� �ޱ�

    [Header("�˸�")]
    [SerializeField] private GameObject notificationBadge;  // ���� �� �˸�
    [SerializeField] private TextMeshProUGUI badgeText;     // �˸� ����

    private List<GameObject> currentMailSlots = new List<GameObject>();
    private List<GameObject> currentRewardSlots = new List<GameObject>();
    private Mail currentSelectedMail;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        SetupButtons();

        // �ʱ� ����
        if (mailPanel != null) mailPanel.SetActive(false);
        if (mailDetailPanel != null) mailDetailPanel.SetActive(false);
        if (couponPanel != null) couponPanel.SetActive(false);

        UpdateNotificationBadge();
    }

    /// <summary>
    /// ��ư �̺�Ʈ ����
    /// </summary>
    private void SetupButtons()
    {
        if (closeMailButton != null)
            closeMailButton.onClick.AddListener(CloseMailPanel);

        if (openCouponButton != null)
            openCouponButton.onClick.AddListener(OpenCouponPanel);

        if (couponSubmitButton != null)
            couponSubmitButton.onClick.AddListener(OnCouponSubmit);

        if (couponCloseButton != null)
            couponCloseButton.onClick.AddListener(CloseCouponPanel);

        if (claimButton != null)
            claimButton.onClick.AddListener(OnClaimReward);

        if (deleteButton != null)
            deleteButton.onClick.AddListener(OnDeleteMail);

        if (backButton != null)
            backButton.onClick.AddListener(BackToMailList);

        if (claimAllButton != null)
            claimAllButton.onClick.AddListener(OnClaimAll);
    }

    #region ���� �г� ����/�ݱ�

    /// <summary>
    /// ������ ����
    /// </summary>
    public void OpenMailPanel()
    {
        if (mailPanel != null)
        {
            mailPanel.SetActive(true);
            ShowMailList();
            RefreshMailList();
        }
    }

    /// <summary>
    /// ������ �ݱ�
    /// </summary>
    public void CloseMailPanel()
    {
        if (mailPanel != null)
        {
            mailPanel.SetActive(false);
        }

        if (mailDetailPanel != null)
        {
            mailDetailPanel.SetActive(false);
        }

        if (couponPanel != null)
        {
            couponPanel.SetActive(false);
        }
    }

    /// <summary>
    /// ���� ��� ǥ��
    /// </summary>
    private void ShowMailList()
    {
        if (mailListPanel != null) mailListPanel.SetActive(true);
        if (mailDetailPanel != null) mailDetailPanel.SetActive(false);
    }

    /// <summary>
    /// ���� ������� ���ư���
    /// </summary>
    private void BackToMailList()
    {
        ShowMailList();
    }

    #endregion

    #region ���� ���

    /// <summary>
    /// ���� ��� ���ΰ�ħ
    /// </summary>
    public void RefreshMailList()
    {
        // ���� ���� ����
        ClearMailSlots();

        if (MailManager.Instance == null)
        {
            Debug.LogWarning("[MailUI] MailManager�� �����ϴ�!");
            return;
        }

        if (mailListContent == null || mailSlotPrefab == null)
        {
            Debug.LogWarning("[MailUI] Mail List Content �Ǵ� Prefab�� �����ϴ�!");
            return;
        }

        List<Mail> mails = MailManager.Instance.GetAllMails();

        // ������ ������
        if (mails.Count == 0)
        {
            Debug.Log("[MailUI] ������ �����ϴ�.");
            return;
        }

        // ���� ���� ����
        foreach (Mail mail in mails)
        {
            GameObject slotObj = Instantiate(mailSlotPrefab, mailListContent);
            MailSlot slot = slotObj.GetComponent<MailSlot>();

            if (slot != null)
            {
                slot.Setup(mail, () => ShowMailDetail(mail));
            }

            currentMailSlots.Add(slotObj);
        }

        UpdateNotificationBadge();

        Debug.Log($"[MailUI] ���� {mails.Count}�� ǥ��");
    }

    /// <summary>
    /// ���� ���� ����
    /// </summary>
    private void ClearMailSlots()
    {
        foreach (GameObject slot in currentMailSlots)
        {
            if (slot != null) Destroy(slot);
        }
        currentMailSlots.Clear();
    }

    #endregion

    #region ���� ��

    /// <summary>
    /// ���� �� ����
    /// </summary>
    private void ShowMailDetail(Mail mail)
    {
        if (mail == null) return;

        Debug.Log($"[Mail ��] ����:{mail.title} | hasReward:{mail.hasReward} | isRewardClaimed:{mail.isRewardClaimed} | �����:{mail.rewards?.Count} | ��¥:{mail.sendDate}");

        currentSelectedMail = mail;

        // ���� ó��
        if (MailManager.Instance != null)
        {
            MailManager.Instance.ReadMail(mail.mailID);
        }

        // �г� ��ȯ
        if (mailListPanel != null) mailListPanel.SetActive(false);
        if (mailDetailPanel != null) mailDetailPanel.SetActive(true);

        // ����
        if (detailTitle != null)
        {
            detailTitle.text = mail.title;
        }

        // ����
        if (detailContent != null)
        {
            detailContent.text = mail.content;
        }

        // ��¥
        if (detailDate != null)
        {
            detailDate.text = mail.sendDate.ToString("yyyy-MM-dd HH:mm");
        }

        // ���� ���
        ShowRewardList(mail.rewards);

        // ��ư ����
        UpdateDetailButtons(mail);

        UpdateNotificationBadge();
    }

    /// <summary>
    /// ���� ��� ǥ��
    /// </summary>
    private void ShowRewardList(List<MailReward> rewards)
    {
        // ���� ���� ���� ����
        ClearRewardSlots();

        if (rewardListContent == null || rewardSlotPrefab == null) return;

        foreach (MailReward reward in rewards)
        {
            GameObject slotObj = Instantiate(rewardSlotPrefab, rewardListContent);
            MailRewardSlot slot = slotObj.GetComponent<MailRewardSlot>();

            if (slot != null)
            {
                slot.Setup(reward);
            }

            currentRewardSlots.Add(slotObj);
        }
    }

    /// <summary>
    /// ���� ���� ����
    /// </summary>
    private void ClearRewardSlots()
    {
        foreach (GameObject slot in currentRewardSlots)
        {
            if (slot != null) Destroy(slot);
        }
        currentRewardSlots.Clear();
    }

    /// <summary>
    /// �� ���� ��ư ������Ʈ
    /// </summary>
    private void UpdateDetailButtons(Mail mail)
    {
        if (claimButton == null) return;

        // �� rewards null ���
        if (mail.rewards == null) mail.rewards = new List<MailReward>();

        bool hasRewards = mail.hasReward && mail.rewards.Count > 0;
        bool canClaim = hasRewards && !mail.isRewardClaimed;

        Debug.Log($"[��ư����] hasReward:{mail.hasReward} rewards.Count:{mail.rewards.Count} canClaim:{canClaim}");

        claimButton.gameObject.SetActive(hasRewards);
        claimButton.interactable = canClaim;

        TextMeshProUGUI buttonText = claimButton.GetComponentInChildren<TextMeshProUGUI>();
        if (buttonText != null)
            buttonText.text = mail.isRewardClaimed ? "���� �Ϸ�" : "�ޱ�";

        if (deleteButton != null)
            deleteButton.interactable = !mail.hasReward || mail.isRewardClaimed;
    }

    /// <summary>
    /// ���� ���� ��ư Ŭ��
    /// </summary>
    private void OnClaimReward()
    {
        if (currentSelectedMail == null || MailManager.Instance == null) return;

        bool success = MailManager.Instance.ClaimMailReward(currentSelectedMail.mailID);

        if (success)
        {
            UpdateDetailButtons(currentSelectedMail);
            RefreshMailList();
        }
    }

    /// <summary>
    /// ���� ��ư Ŭ��
    /// </summary>
    private void OnDeleteMail()
    {
        if (currentSelectedMail == null || MailManager.Instance == null) return;

        MailManager.Instance.DeleteMail(currentSelectedMail.mailID);

        BackToMailList();
        RefreshMailList();
    }

    /// <summary>
    /// ��� �ޱ� ��ư
    /// </summary>
    private void OnClaimAll()
    {
        if (MailManager.Instance == null) return;

        // ��� �̼��� ���� ����
        List<Mail> mails = MailManager.Instance.GetAllMails();
        int claimed = 0;

        foreach (Mail mail in mails)
        {
            if (mail.hasReward && !mail.isRewardClaimed)
            {
                if (MailManager.Instance.ClaimMailReward(mail.mailID))
                {
                    claimed++;
                }
            }
        }

        if (claimed > 0)
        {
            RefreshMailList();

            if (UIManager.Instance != null)
            {
                UIManager.Instance.ShowMessage($"{claimed}�� ������ �޾ҽ��ϴ�!", Color.green);
            }
        }
    }

    #endregion

    #region ����

    /// <summary>
    /// ���� �Է� â ����
    /// </summary>
    private void OpenCouponPanel()
    {
        if (couponPanel != null)
        {
            couponPanel.SetActive(true);

            if (couponInput != null)
            {
                couponInput.text = "";
                couponInput.ActivateInputField();
            }
        }
    }

    /// <summary>
    /// ���� �Է� â �ݱ�
    /// </summary>
    private void CloseCouponPanel()
    {
        if (couponPanel != null)
        {
            couponPanel.SetActive(false);
        }
    }

    /// <summary>
    /// ���� ����
    /// </summary>
    private void OnCouponSubmit()
    {
        if (couponInput == null || MailManager.Instance == null) return;

        string code = couponInput.text.Trim().ToUpper();

        if (string.IsNullOrEmpty(code))
        {
            if (UIManager.Instance != null)
            {
                UIManager.Instance.ShowMessage("���� �ڵ带 �Է��ϼ���!", Color.red);
            }
            return;
        }

        bool success = MailManager.Instance.RedeemCouponCode(code);

        if (success)
        {
            CloseCouponPanel();
            RefreshMailList();
            couponInput.text = "";
        }
    }

    #endregion

    #region �˸� ����

    /// <summary>
    /// �˸� ���� ������Ʈ
    /// </summary>
    public void UpdateNotificationBadge()
    {
        if (MailManager.Instance == null) return;

        int unreadCount = MailManager.Instance.GetUnreadMailCount();
        int rewardCount = MailManager.Instance.GetUnclaimedRewardCount();

        if (notificationBadge != null)
        {
            notificationBadge.SetActive(unreadCount > 0 || rewardCount > 0);
        }

        if (badgeText != null)
        {
            int total = unreadCount + rewardCount;
            badgeText.text = total > 99 ? "99+" : total.ToString();
        }
    }

    #endregion
}




