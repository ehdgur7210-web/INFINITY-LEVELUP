﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ============================================================
/// EquipmentSkillSystem — 장비 슬롯별 등급별 스킬 연동 시스템
/// ============================================================
/// 
/// ★ 핫바 배치 구조 (6열 x 5행):
/// 
///   열:  왼손무기  오른손무기  투구  갑옷  장갑  신발
///   행0: [  0  ] [  1  ] [  2  ] [  3  ] [  4  ] [  5  ]  ← Common
///   행1: [  6  ] [  7  ] [  8  ] [  9  ] [ 10  ] [ 11  ]  ← Uncommon
///   행2: [ 12  ] [ 13  ] [ 14  ] [ 15  ] [ 16  ] [ 17  ]  ← Rare
///   행3: [ 18  ] [ 19  ] [ 20  ] [ 21  ] [ 22  ] [ 23  ]  ← Epic
///   행4: [ 24  ] [ 25  ] [ 26  ] [ 27  ] [ 28  ] [ 29  ]  ← Legendary
/// 
/// ★ 핫바 슬롯이 30개 이상 있어야 정상 작동합니다!
/// </summary>
public class EquipmentSkillSystem : MonoBehaviour
{
    public static EquipmentSkillSystem Instance { get; private set; }

    [Header("장비 슬롯별 등급별 스킬 매핑")]
    [Tooltip("왼손 무기 슬롯의 등급별 스킬")]
    public RaritySkillMapping weaponLeftSkills;

    [Tooltip("오른손 무기 슬롯의 등급별 스킬")]
    public RaritySkillMapping weaponRightSkills;

    [Tooltip("투구 슬롯의 등급별 스킬")]
    public RaritySkillMapping helmetSkills;

    [Tooltip("갑옷 슬롯의 등급별 스킬")]
    public RaritySkillMapping armorSkills;

    [Tooltip("장갑 슬롯의 등급별 스킬")]
    public RaritySkillMapping glovesSkills;

    [Tooltip("신발 슬롯의 등급별 스킬")]
    public RaritySkillMapping bootsSkills;

    private Dictionary<EquipmentType, RaritySkillMapping> slotSkillMap =
        new Dictionary<EquipmentType, RaritySkillMapping>();

    private Dictionary<EquipmentType, SkillData> activeSkills =
        new Dictionary<EquipmentType, SkillData>();

    // ─── 핫바 배치 계산용 상수 ───────────────────────────────
    // 열(Column): 장비 슬롯 종류 (6개)
    private const int NUM_EQUIPMENT_SLOTS = 6;

    // 장비 슬롯 → 열 인덱스 매핑
    // 왼손=0열, 오른손=1열, 투구=2열, 갑옷=3열, 장갑=4열, 신발=5열
    private static readonly Dictionary<EquipmentType, int> equipmentColumnIndex
        = new Dictionary<EquipmentType, int>
    {
        { EquipmentType.WeaponLeft,  0 },
        { EquipmentType.WeaponRight, 1 },
        { EquipmentType.Helmet,      2 },
        { EquipmentType.Armor,       3 },
        { EquipmentType.Gloves,      4 },
        { EquipmentType.Boots,       5 },
    };

    // 등급 → 행(Row) 인덱스 매핑
    // Common=0행(맨 위), Uncommon=1행, Rare=2행, Epic=3행, Legendary=4행
    private static readonly Dictionary<ItemRarity, int> rarityRowIndex
        = new Dictionary<ItemRarity, int>
    {
        { ItemRarity.Common,    0 },
        { ItemRarity.Uncommon,  1 },
        { ItemRarity.Rare,      2 },
        { ItemRarity.Epic,      3 },
        { ItemRarity.Legendary, 4 },
    };
    // ────────────────────────────────────────────────────────

    void Awake()
    {
        if (Instance == null)
            Instance = this;
        else
        {
            Destroy(gameObject);
            return;
        }

        BuildSlotSkillMap();
    }

    private void BuildSlotSkillMap()
    {
        slotSkillMap.Clear();

        slotSkillMap[EquipmentType.WeaponLeft] = weaponLeftSkills;
        slotSkillMap[EquipmentType.WeaponRight] = weaponRightSkills;
        slotSkillMap[EquipmentType.Helmet] = helmetSkills;
        slotSkillMap[EquipmentType.Armor] = armorSkills;
        slotSkillMap[EquipmentType.Gloves] = glovesSkills;
        slotSkillMap[EquipmentType.Boots] = bootsSkills;

        Debug.Log($"[EquipmentSkillSystem] 등급별 매핑 테이블 구성 완료: {slotSkillMap.Count}개 슬롯");
    }

    // ───────────────────────────────────────────────────────
    /// <summary>
    /// ★ 핫바 슬롯 인덱스 계산
    /// 행(등급) * 6 + 열(장비슬롯) = 핫바 슬롯 번호
    /// 예) 장갑(열4) + Uncommon(행1) → 1*6+4 = 10번 슬롯
    /// </summary>
    private int GetHotbarSlotIndex(EquipmentType slotType, ItemRarity rarity)
    {
        if (!equipmentColumnIndex.TryGetValue(slotType, out int col))
        {
            Debug.LogWarning($"[EquipmentSkillSystem] {slotType}의 열 인덱스가 없습니다!");
            return -1;
        }
        if (!rarityRowIndex.TryGetValue(rarity, out int row))
        {
            Debug.LogWarning($"[EquipmentSkillSystem] {rarity}의 행 인덱스가 없습니다!");
            return -1;
        }

        int hotbarIndex = row * NUM_EQUIPMENT_SLOTS + col;
        Debug.Log($"[EquipmentSkillSystem] {slotType}({col}열) + {rarity}({row}행) → 핫바 {hotbarIndex}번 슬롯");
        return hotbarIndex;
    }
    // ───────────────────────────────────────────────────────

    public void OnEquipmentEquipped(EquipmentType slotType, EquipmentData equipment)
    {
        if (equipment == null)
        {
            Debug.LogWarning($"[EquipmentSkillSystem] {slotType} - equipment가 null입니다!");
            return;
        }

        if (!slotSkillMap.TryGetValue(slotType, out RaritySkillMapping skillMapping))
        {
            Debug.Log($"[EquipmentSkillSystem] {slotType} 슬롯 매핑 없음");
            return;
        }

        SkillData skill = skillMapping.GetSkillByRarity(equipment.rarity);

        if (skill == null)
        {
            Debug.Log($"[EquipmentSkillSystem] {slotType} - {equipment.rarity} 등급 스킬이 설정되지 않음");
            DeactivateSkill(slotType);
            return;
        }

        Debug.Log($"[EquipmentSkillSystem] {slotType} 스킬 활성화 — 스킬: {skill.skillName}, 등급: {equipment.rarity}");
        ActivateSkill(slotType, skill, equipment.rarity);
    }

    public void OnEquipmentUnequipped(EquipmentType slotType)
    {
        DeactivateSkill(slotType);
    }

    private void ActivateSkill(EquipmentType slotType, SkillData skill, ItemRarity rarity)
    {
        // 이전 스킬 정보 기억
        SkillData oldSkill = null;
        activeSkills.TryGetValue(slotType, out oldSkill);

        // ★ 같은 스킬이라도 핫바에서 사라졌을 수 있으므로 무조건 실행하도록 변경
        activeSkills[slotType] = skill;

        if (SkillManager.Instance != null)
        {
            int targetSlotIndex = GetHotbarSlotIndex(slotType, rarity);

            // 핫바가 아직 안 만들어졌을 때를 대비해 한 번 더 안전장치
            SkillManager.Instance.SwapEquipmentSkillOnHotbarAtIndex(oldSkill, skill, targetSlotIndex);
        }

        if (UIManager.Instance != null)
        {
            Color messageColor = GetRarityColor(rarity);
            UIManager.Instance.ShowMessage($"⭐ {rarity} {skill.skillName} 활성화!", messageColor);
        }
    }

    private void DeactivateSkill(EquipmentType slotType)
    {
        if (!activeSkills.TryGetValue(slotType, out SkillData skill) || skill == null)
            return;

        if (SkillManager.Instance != null)
            SkillManager.Instance.RemoveSkillFromEquipment(skill);

        activeSkills.Remove(slotType);
        Debug.Log($"[EquipmentSkillSystem] {skill.skillName} 비활성화 (슬롯: {slotType})");
    }

    private Color GetRarityColor(ItemRarity rarity)
    {
        switch (rarity)
        {
            case ItemRarity.Common: return Color.white;
            case ItemRarity.Uncommon: return Color.green;
            case ItemRarity.Rare: return Color.blue;
            case ItemRarity.Epic: return new Color(0.58f, 0f, 0.83f);  // 보라색
            case ItemRarity.Legendary: return new Color(1f, 0.5f, 0f);      // 주황색
            default: return Color.white;
        }
    }

    public bool IsSkillActive(EquipmentType slotType)
    {
        return activeSkills.ContainsKey(slotType) && activeSkills[slotType] != null;
    }

    public SkillData GetActiveSkillForSlot(EquipmentType slotType)
    {
        activeSkills.TryGetValue(slotType, out SkillData skill);
        return skill;
    }

    public List<SkillData> GetAllActiveSkills()
    {
        var list = new List<SkillData>();
        foreach (var skill in activeSkills.Values)
            if (skill != null)
                list.Add(skill);
        return list;
    }

    public RaritySkillMapping GetSkillMappingForSlot(EquipmentType slotType)
    {
        slotSkillMap.TryGetValue(slotType, out RaritySkillMapping mapping);
        return mapping;
    }
    public void RefreshAllEquippedSkills()
    {
        Debug.Log("[EquipmentSkillSystem] 모든 장착 장비 스킬 새로고침 시작");

        // 현재 장착 중인 장비 데이터를 가져와서 다시 OnEquipmentEquipped를 실행
        // 인벤토리 매니저나 장비 매니저에서 현재 끼고 있는 아이템 리스트를 가져와야 합니다.
        // 예시: (실제 프로젝트의 장비 관리 스크립트에 맞춰 수정 필요)
        /*
        foreach(var slot in EquipmentManager.Instance.equippedItems)
        {
            if(slot.Value != null)
                OnEquipmentEquipped(slot.Key, slot.Value);
        }
        */

        // 만약 위 참조가 어렵다면, 현재 activeSkills에 담긴 정보를 다시 핫바에 매핑
        foreach (var kvp in activeSkills)
        {
            if (kvp.Value != null)
            {
                // 해당 등급을 찾기 위해선 equipment 데이터가 필요하므로 
                // 가급적 장착 시점의 장비를 기억해두는 것이 좋습니다.
                // 여기서는 이미 활성화된 스킬만이라도 핫바에 다시 꽂아줍니다.
                int targetIndex = GetHotbarSlotIndex(kvp.Key, GetRarityFromSkill(kvp.Value));
                SkillManager.Instance.SwapEquipmentSkillOnHotbarAtIndex(null, kvp.Value, targetIndex);
            }
        }
    }

    // 스킬을 통해 해당 등급을 역추적하는 헬퍼 함수 (필요 시)
    private ItemRarity GetRarityFromSkill(SkillData skill)
    {
        // 이 부분은 장비 데이터에서 직접 rarity를 가져오는 것이 가장 정확합니다.
        return ItemRarity.Common; // 기본값
    }
    [ContextMenu("Debug: Print Active Skills")]
    public void DebugPrintActiveSkills()
    {
        Debug.Log("========== 현재 활성화된 스킬 ==========");
        foreach (var kvp in activeSkills)
            if (kvp.Value != null)
                Debug.Log($"{kvp.Key}: {kvp.Value.skillName}");
        Debug.Log($"총 {activeSkills.Count}개 활성화");
        Debug.Log("=========================================");
    }
}