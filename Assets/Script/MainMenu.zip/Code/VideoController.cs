using UnityEngine;
using UnityEngine.Video;
using UnityEngine.SceneManagement;

public class VideoController : MonoBehaviour
{
    [Header("����")]
    public VideoPlayer videoPlayer;

    [Header("��� �� �̵��� ��")]
    public string nextSceneName = "MainMenu";

    [Header("��ŵ ���")]
    public bool allowSkip = true;

    void Start()
    {
        if (videoPlayer != null)
        {
            videoPlayer.loopPointReached += OnVideoEnd;
            videoPlayer.Play();
        }
    }

    void Update()
    {
        // �ƹ� Ű�� ��ġ�� ��ŵ
        if (allowSkip && (Input.anyKeyDown || Input.touchCount > 0))
        {
            GoToNextScene();
        }
    }

    void OnVideoEnd(VideoPlayer vp)
    {
        GoToNextScene();
    }

    void GoToNextScene()
    {
        SceneManager.LoadScene(nextSceneName);
    }
}