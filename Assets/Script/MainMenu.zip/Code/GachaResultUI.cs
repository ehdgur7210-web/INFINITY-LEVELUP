﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// 가챠 결과 UI (EquipmentData 기반)
/// - 10연차 애니메이션
/// - 희귀도별 색상
/// </summary>
public class GachaResultUI : MonoBehaviour
{
    public static GachaResultUI Instance;

    [Header("UI 참조")]
    public GameObject resultPanel;              // 결과 패널
    public Transform resultSlotParent;          // 결과 슬롯 부모
    public GameObject resultSlotPrefab;         // 결과 슬롯 프리팹
    public Button closeButton;                  // 닫기 버튼

    [Header("애니메이션 설정")]
    public float slotAppearDelay = 0.15f;       // 슬롯 나타나는 간격
    public float slotAnimationDuration = 0.3f;  // 슬롯 애니메이션 시간

    [Header("효과음")]
    public AudioClip revealSound;               // 결과 공개 사운드
    public AudioClip rareSound;                 // 희귀 이상 사운드

    private List<GameObject> currentResultSlots = new List<GameObject>();
    private AudioSource audioSource;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }

        audioSource = GetComponent<AudioSource>();
        if (audioSource == null)
        {
            audioSource = gameObject.AddComponent<AudioSource>();
        }
    }

    void Start()
    {
        // 닫기 버튼 이벤트 연결
        if (closeButton != null)
        {
            closeButton.onClick.AddListener(CloseResults);
        }

        // 초기에는 결과 패널 닫기
        if (resultPanel != null)
        {
            resultPanel.SetActive(false);
        }
    }

    /// <summary>
    /// ⭐ 가챠 결과 표시 (EquipmentData)
    /// </summary>
    public void ShowResults(List<EquipmentData> results)
    {
        if (results == null || results.Count == 0)
        {
            Debug.LogWarning("[GachaResultUI] 표시할 결과가 없습니다!");
            return;
        }

        Debug.Log($"[GachaResultUI] 결과 표시: {results.Count}개");

        // 패널 열기
        if (resultPanel != null)
        {
            resultPanel.SetActive(true);
        }

        // 기존 슬롯 제거
        ClearResultSlots();

        // 애니메이션으로 결과 표시
        StartCoroutine(ShowResultsAnimation(results));
    }

    /// <summary>
    /// 결과 애니메이션 코루틴
    /// </summary>
    IEnumerator ShowResultsAnimation(List<EquipmentData> results)
    {
        for (int i = 0; i < results.Count; i++)
        {
            EquipmentData equipment = results[i];

            // 결과 슬롯 생성
            GameObject slotObj = Instantiate(resultSlotPrefab, resultSlotParent);
            GachaResultSlot slot = slotObj.GetComponent<GachaResultSlot>();

            if (slot != null)
            {
                // 초기 스케일을 0으로 설정
                slotObj.transform.localScale = Vector3.zero;

                // 슬롯 설정
                slot.SetupSlot(equipment);

                // 애니메이션 실행
                StartCoroutine(AnimateSlot(slotObj));

                // 효과음 재생
                PlayRevealSound(equipment.rarity);
            }

            currentResultSlots.Add(slotObj);

            // 다음 슬롯까지 대기
            yield return new WaitForSeconds(slotAppearDelay);
        }
    }

    /// <summary>
    /// 슬롯 애니메이션 (튀어나오는 효과)
    /// </summary>
    IEnumerator AnimateSlot(GameObject slot)
    {
        float elapsed = 0f;
        Vector3 targetScale = Vector3.one;

        while (elapsed < slotAnimationDuration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / slotAnimationDuration;

            // EaseOutBack 효과
            float overshoot = 1.70158f;
            t = t - 1f;
            float scale = 1f + overshoot * t * t * t + t * t;

            slot.transform.localScale = targetScale * scale;

            yield return null;
        }

        slot.transform.localScale = targetScale;
    }

    /// <summary>
    /// 결과 공개 사운드 재생
    /// </summary>
    void PlayRevealSound(ItemRarity rarity)
    {
        if (audioSource == null) return;

        // 희귀 이상이면 특별 사운드
        if (rarity >= ItemRarity.Rare && rareSound != null)
        {
            audioSource.PlayOneShot(rareSound);
        }
        else if (revealSound != null)
        {
            audioSource.PlayOneShot(revealSound);
        }
    }

    /// <summary>
    /// 기존 결과 슬롯 제거
    /// </summary>
    void ClearResultSlots()
    {
        foreach (GameObject slot in currentResultSlots)
        {
            if (slot != null)
            {
                Destroy(slot);
            }
        }

        currentResultSlots.Clear();
    }

    /// <summary>
    /// 결과 패널 닫기
    /// </summary>
    public void CloseResults()
    {
        if (resultPanel != null)
        {
            resultPanel.SetActive(false);
        }

        ClearResultSlots();
    }
}

/// <summary>
/// 가챠 결과 슬롯 (EquipmentData 표시)
/// </summary>
public class GachaResultSlot : MonoBehaviour
{
    [Header("UI 참조")]
    public Image itemIconImage;             // 아이템 아이콘
    public Image backgroundImage;           // 배경 이미지
    public TextMeshProUGUI itemNameText;    // 아이템 이름
    public TextMeshProUGUI rarityText;      // 희귀도 텍스트
    public GameObject newBadge;             // NEW 뱃지

    /// <summary>
    /// ⭐ 슬롯 설정 (EquipmentData)
    /// </summary>
    public void SetupSlot(EquipmentData equipment)
    {
        if (equipment == null) return;

        // 아이템 아이콘
        if (itemIconImage != null)
        {
            itemIconImage.sprite = equipment.itemIcon;
            itemIconImage.color = Color.white;
        }

        // 아이템 이름
        if (itemNameText != null)
        {
            itemNameText.text = equipment.itemName;
        }

        // 희귀도 텍스트
        if (rarityText != null)
        {
            rarityText.text = GetRarityText(equipment.rarity);
            rarityText.color = GetRarityColor(equipment.rarity);
        }

        // 배경색 (희귀도에 따라)
        if (backgroundImage != null)
        {
            backgroundImage.color = GetRarityColor(equipment.rarity);
        }

        // NEW 뱃지 (희귀 이상만)
        if (newBadge != null)
        {
            newBadge.SetActive(equipment.rarity >= ItemRarity.Rare);
        }
    }

    /// <summary>
    /// 희귀도 텍스트 반환
    /// </summary>
    string GetRarityText(ItemRarity rarity)
    {
        switch (rarity)
        {
            case ItemRarity.Common:
                return "일반";
            case ItemRarity.Uncommon:
                return "고급";
            case ItemRarity.Rare:
                return "희귀";
            case ItemRarity.Epic:
                return "영웅";
            case ItemRarity.Legendary:
                return "전설";
            default:
                return "알 수 없음";
        }
    }

    /// <summary>
    /// 희귀도 색상 반환
    /// </summary>
    Color GetRarityColor(ItemRarity rarity)
    {
        switch (rarity)
        {
            case ItemRarity.Common:
                return new Color(0.7f, 0.7f, 0.7f);     // 회색
            case ItemRarity.Uncommon:
                return new Color(0.2f, 0.9f, 0.2f);     // 초록
            case ItemRarity.Rare:
                return new Color(0.3f, 0.6f, 1f);       // 파랑
            case ItemRarity.Epic:
                return new Color(0.7f, 0.3f, 1f);       // 보라
            case ItemRarity.Legendary:
                return new Color(1f, 0.7f, 0.1f);       // 주황
            default:
                return Color.white;
        }
    }
}