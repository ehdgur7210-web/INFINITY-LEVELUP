using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ServerButton : MonoBehaviour
{
    [Header("UI ���")]
    [SerializeField] private TextMeshProUGUI serverNameText;
    [SerializeField] private TextMeshProUGUI statusText;
    [SerializeField] private TextMeshProUGUI populationText;
    [SerializeField] private Image statusIcon;
    [SerializeField] private Button button;

    private ServerInfo serverInfo;
    private System.Action onClickCallback;

    /// <summary>
    /// ��ư ����
    /// </summary>
    public void SetupButton(ServerInfo info, System.Action onClick)
    {
        serverInfo = info;
        onClickCallback = onClick;

        // �ؽ�Ʈ ����
        if (serverNameText != null)
            serverNameText.text = info.serverName;

        if (statusText != null)
            statusText.text = GetStatusText(info.serverStatus);

        if (populationText != null)
            populationText.text = $"{info.currentPlayers}/{info.maxPlayers}";

        // ���� ������ ����
        if (statusIcon != null)
            statusIcon.color = GetStatusColor(info.serverStatus);

        // ��ư �̺�Ʈ
        if (button != null)
        {
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(OnButtonClicked);

            // �������̸� ��ư ��Ȱ��ȭ
            button.interactable = info.serverStatus != ServerStatus.Maintenance;
        }
    }

    private void OnButtonClicked()
    {
        onClickCallback?.Invoke();
    }

    private string GetStatusText(ServerStatus status)
    {
        switch (status)
        {
            case ServerStatus.Normal: return "����";
            case ServerStatus.Crowded: return "ȥ��";
            case ServerStatus.Maintenance: return "������";
            default: return "�� �� ����";
        }
    }

    private Color GetStatusColor(ServerStatus status)
    {
        switch (status)
        {
            case ServerStatus.Normal: return Color.green;
            case ServerStatus.Crowded: return Color.yellow;
            case ServerStatus.Maintenance: return Color.red;
            default: return Color.gray;
        }
    }
}