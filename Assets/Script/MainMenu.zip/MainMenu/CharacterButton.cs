using TMPro;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class CharacterData
{
    public string characterName;
    public CharacterType characterType;
    public string description;

    [Header("�⺻ ����")]
    public float baseHealth;
    public float baseAttack;
    public float baseDefense;
    public float baseSpeed;
    public float attackRange;
    public float attackSpeed;

    [Header("���־�")]
    public Sprite previewSprite;
    public GameObject characterPrefab; // ���� ���ӿ��� ����� ������
}

/// <summary>
/// ĳ���� Ÿ��
/// </summary>
public enum CharacterType
{
    Melee,   // �ٰŸ�
    Ranged   // ���Ÿ�
}
public class CharacterButton : MonoBehaviour
{
    [Header("UI ���")]
    [SerializeField] private TextMeshProUGUI characterNameText;
    [SerializeField] private TextMeshProUGUI characterTypeText;
    [SerializeField] private Image characterIcon;
    [SerializeField] private Button button;

    private CharacterData characterData;
    private System.Action onClickCallback;

    private void Awake()
    {
        // button�� �Ҵ���� �ʾҴٸ� �ڵ����� ã��
        if (button == null)
        {
            button = GetComponent<Button>();
            Debug.Log($"[CharacterButton] Button �ڵ� �Ҵ�: {button != null}");
        }
    }

    /// <summary>
    /// ��ư ����
    /// </summary>
    public void SetupButton(CharacterData data, System.Action onClick)
    {
        Debug.Log($"[CharacterButton] ===== SetupButton ����: {data.characterName} =====");

        characterData = data;
        onClickCallback = onClick;

        // �ؽ�Ʈ ����
        if (characterNameText != null)
        {
            characterNameText.text = data.characterName;
            Debug.Log($"[CharacterButton] �̸� �ؽ�Ʈ ����: {data.characterName}");
        }
        else
            Debug.LogWarning($"[CharacterButton] characterNameText�� null! ({data.characterName})");

        if (characterTypeText != null)
        {
            string typeText = data.characterType == CharacterType.Melee ? "�ٰŸ�" : "���Ÿ�";
            characterTypeText.text = typeText;
            Color typeColor = data.characterType == CharacterType.Melee ?
                new Color(1f, 0.5f, 0.5f) : new Color(0.5f, 0.5f, 1f);
            characterTypeText.color = typeColor;
            Debug.Log($"[CharacterButton] Ÿ�� �ؽ�Ʈ ����: {typeText}");
        }

        // ������ ����
        if (characterIcon != null && data.previewSprite != null)
        {
            characterIcon.sprite = data.previewSprite;
            Debug.Log($"[CharacterButton] ������ ���� �Ϸ�");
        }

        // ��ư �̺�Ʈ
        if (button != null)
        {
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(OnButtonClicked);
            Debug.Log($"[CharacterButton] ��ư ������ ���: {data.characterName}");
        }
        else
        {
            Debug.LogError($"[CharacterButton] Button�� null! ({data.characterName})");
        }

        Debug.Log($"[CharacterButton] ===== SetupButton �Ϸ�: {data.characterName} =====");
    }

    private void OnButtonClicked()
    {
        Debug.Log($"[CharacterButton] OnButtonClicked ȣ���");

        if (characterData != null)
        {
            Debug.Log($"[CharacterButton] ĳ���� ������: {characterData.characterName}");
        }
        else
        {
            Debug.LogError("[CharacterButton] characterData�� null�Դϴ�!");
        }

        if (onClickCallback != null)
        {
            Debug.Log($"[CharacterButton] �ݹ� ����");
            onClickCallback.Invoke();
        }
        else
        {
            Debug.LogError("[CharacterButton] onClickCallback�� null�Դϴ�!");
        }
    }
}
