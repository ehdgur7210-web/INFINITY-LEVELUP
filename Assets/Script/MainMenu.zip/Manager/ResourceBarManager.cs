using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// �ֿ� ����/Ƽ���� ǥ���ϴ� ��� ���ҽ� ��
/// ��í Ƽ��, ���� Ƽ��, ���� Ƽ�� ���� �׻� ǥ��
/// </summary>
public class ResourceBarManager : MonoBehaviour
{
    public static ResourceBarManager Instance;

    [Header("�г� UI")]
    [SerializeField] private GameObject penal;
    [SerializeField] private Button Togl;


    [Header("Ƽ�� UI")]
    [SerializeField] private TextMeshProUGUI equipmentTicketText;   // ��� �̱� Ƽ��
    [SerializeField] private TextMeshProUGUI companionTicketText;   // ���� �̱� Ƽ��
    [SerializeField] private TextMeshProUGUI relicTicketText;       // ���� �̱� Ƽ��

    [Header("Ƽ�� ������ (����)")]
    [SerializeField] private Image equipmentTicketIcon;
    [SerializeField] private Image companionTicketIcon;
    [SerializeField] private Image relicTicketIcon;

    [Header("���� UI (�߰� ����)")]
    [SerializeField] private TextMeshProUGUI crystalText;           // ũ����Ż
    [SerializeField] private TextMeshProUGUI essenceText;           // ������
    [SerializeField] private TextMeshProUGUI fragmentText;          // ����

    [Header("���� ������ (����)")]
    [SerializeField] private Image crystalIcon;
    [SerializeField] private Image essenceIcon;
    [SerializeField] private Image fragmentIcon;

    [Header("���� ������")]
    public int equipmentTickets = 100;      // ��� �̱� Ƽ��
    public int companionTickets = 50;       // ���� �̱� Ƽ��
    public int relicTickets = 30;           // ���� �̱� Ƽ��
    public int crystals = 0;                // ũ����Ż
    public int essences = 0;                // ������
    public int fragments = 0;               // ����

    [Header("�ִϸ��̼� ����")]
    [SerializeField] private bool enablePunchAnimation = true;
    [SerializeField] private float punchScale = 1.1f;
    [SerializeField] private float animationDuration = 0.2f;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        UpdateAllResourceUI();

        // ��� ��ư �̺�Ʈ ���� �߰�
        if (Togl != null)
        {
            Togl.onClick.AddListener(ToggleResourceBar);
            Debug.Log("[ResourceBar] ��� ��ư �̺�Ʈ �����!");
        }
        else
        {
            Debug.LogError("[ResourceBar] Togl ��ư�� null�Դϴ�! Inspector���� �����ϼ���!");
        }

        // ���� �� �г� ǥ��
        HidePenal();
    }

    public void HidePenal()
    {
        if(penal != null)
        {
            penal.SetActive(false);
        }
        

    }

    public void ShowPenal()
    {
        penal.SetActive(true);
    }

    public void ToggleResourceBar()
    {
        if (penal != null)
        {
            bool isActive = penal.activeSelf;
            if (isActive) HidePenal();
            else ShowPenal();
        }
    }
    public bool IsBarVisible()
    {
        return penal != null && penal.activeSelf;
    }
    #region Ƽ�� ����

    /// <summary>
    /// ��� Ƽ�� �߰�
    /// </summary>
    public void AddEquipmentTickets(int amount)
    {
        equipmentTickets += amount;
        UpdateEquipmentTicketUI();

        if (enablePunchAnimation && equipmentTicketText != null)
        {
            AnimateText(equipmentTicketText.transform);
        }

        Debug.Log($"[ResourceBar] ��� Ƽ�� +{amount} (����: {equipmentTickets})");
    }

    /// <summary>
    /// ��� Ƽ�� ���
    /// </summary>
    public bool SpendEquipmentTickets(int amount)
    {
        if (equipmentTickets < amount)
        {
            Debug.LogWarning($"[ResourceBar] ��� Ƽ�� ����! (�ʿ�: {amount}, ����: {equipmentTickets})");
            return false;
        }

        equipmentTickets -= amount;
        UpdateEquipmentTicketUI();

        Debug.Log($"[ResourceBar] ��� Ƽ�� -{amount} (����: {equipmentTickets})");
        return true;
    }

    /// <summary>
    /// ���� Ƽ�� �߰�
    /// </summary>
    public void AddCompanionTickets(int amount)
    {
        companionTickets += amount;
        UpdateCompanionTicketUI();

        if (enablePunchAnimation && companionTicketText != null)
        {
            AnimateText(companionTicketText.transform);
        }

        Debug.Log($"[ResourceBar] ���� Ƽ�� +{amount} (����: {companionTickets})");
    }

    /// <summary>
    /// ���� Ƽ�� ���
    /// </summary>
    public bool SpendCompanionTickets(int amount)
    {
        if (companionTickets < amount)
        {
            Debug.LogWarning($"[ResourceBar] ���� Ƽ�� ����! (�ʿ�: {amount}, ����: {companionTickets})");
            return false;
        }

        companionTickets -= amount;
        UpdateCompanionTicketUI();

        Debug.Log($"[ResourceBar] ���� Ƽ�� -{amount} (����: {companionTickets})");
        return true;
    }

    /// <summary>
    /// ���� Ƽ�� �߰�
    /// </summary>
    public void AddRelicTickets(int amount)
    {
        relicTickets += amount;
        UpdateRelicTicketUI();

        if (enablePunchAnimation && relicTicketText != null)
        {
            AnimateText(relicTicketText.transform);
        }

        Debug.Log($"[ResourceBar] ���� Ƽ�� +{amount} (����: {relicTickets})");
    }

    /// <summary>
    /// ���� Ƽ�� ���
    /// </summary>
    public bool SpendRelicTickets(int amount)
    {
        if (relicTickets < amount)
        {
            Debug.LogWarning($"[ResourceBar] ���� Ƽ�� ����! (�ʿ�: {amount}, ����: {relicTickets})");
            return false;
        }

        relicTickets -= amount;
        UpdateRelicTicketUI();

        Debug.Log($"[ResourceBar] ���� Ƽ�� -{amount} (����: {relicTickets})");
        return true;
    }

    #endregion

    #region ���� ����

    /// <summary>
    /// ũ����Ż �߰�
    /// </summary>
    public void AddCrystals(int amount)
    {
        crystals += amount;
        UpdateCrystalUI();

        if (enablePunchAnimation && crystalText != null)
        {
            AnimateText(crystalText.transform);
        }
    }

    /// <summary>
    /// ũ����Ż ���
    /// </summary>
    public bool SpendCrystals(int amount)
    {
        if (crystals < amount) return false;

        crystals -= amount;
        UpdateCrystalUI();
        return true;
    }

    /// <summary>
    /// ������ �߰�
    /// </summary>
    public void AddEssences(int amount)
    {
        essences += amount;
        UpdateEssenceUI();

        if (enablePunchAnimation && essenceText != null)
        {
            AnimateText(essenceText.transform);
        }
    }

    /// <summary>
    /// ������ ���
    /// </summary>
    public bool SpendEssences(int amount)
    {
        if (essences < amount) return false;

        essences -= amount;
        UpdateEssenceUI();
        return true;
    }

    /// <summary>
    /// ���� �߰�
    /// </summary>
    public void AddFragments(int amount)
    {
        fragments += amount;
        UpdateFragmentUI();

        if (enablePunchAnimation && fragmentText != null)
        {
            AnimateText(fragmentText.transform);
        }
    }

    /// <summary>
    /// ���� ���
    /// </summary>
    public bool SpendFragments(int amount)
    {
        if (fragments < amount) return false;

        fragments -= amount;
        UpdateFragmentUI();
        return true;
    }

    #endregion

    #region UI ������Ʈ

    public void UpdateEquipmentTicketUI()
    {
        if (equipmentTicketText != null)
        {
            equipmentTicketText.text = FormatNumber(equipmentTickets);
        }
    }

    private void UpdateCompanionTicketUI()
    {
        if (companionTicketText != null)
        {
            companionTicketText.text = FormatNumber(companionTickets);
        }
    }

    private void UpdateRelicTicketUI()
    {
        if (relicTicketText != null)
        {
            relicTicketText.text = FormatNumber(relicTickets);
        }
    }

    private void UpdateCrystalUI()
    {
        if (crystalText != null)
        {
            crystalText.text = FormatNumber(crystals);
        }
    }

    private void UpdateEssenceUI()
    {
        if (essenceText != null)
        {
            essenceText.text = FormatNumber(essences);
        }
    }

    private void UpdateFragmentUI()
    {
        if (fragmentText != null)
        {
            fragmentText.text = FormatNumber(fragments);
        }
    }

    /// <summary>
    /// ��� ���ҽ� UI ������Ʈ
    /// </summary>
    public void UpdateAllResourceUI()
    {
        UpdateEquipmentTicketUI();
        UpdateCompanionTicketUI();
        UpdateRelicTicketUI();
        UpdateCrystalUI();
        UpdateEssenceUI();
        UpdateFragmentUI();
    }

    #endregion

    #region ��ƿ��Ƽ

    /// <summary>
    /// ���� ������ (õ ���� �޸�)
    /// </summary>
    private string FormatNumber(int number)
    {
        if (number >= 1000000)
        {
            return $"{number / 1000000f:F1}M";
        }
        else if (number >= 1000)
        {
            return $"{number / 1000f:F1}K";
        }
        else
        {
            return number.ToString();
        }
    }

    /// <summary>
    /// �ؽ�Ʈ ��ġ �ִϸ��̼�
    /// </summary>
    private void AnimateText(Transform textTransform)
    {
        if (textTransform == null) return;

        StopAllCoroutines();
        StartCoroutine(PunchAnimation(textTransform));
    }

    private System.Collections.IEnumerator PunchAnimation(Transform target)
    {
        Vector3 originalScale = target.localScale;
        Vector3 targetScale = originalScale * punchScale;

        float elapsed = 0f;

        // Ȯ��
        while (elapsed < animationDuration / 2f)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / (animationDuration / 2f);
            target.localScale = Vector3.Lerp(originalScale, targetScale, t);
            yield return null;
        }

        elapsed = 0f;

        // ���
        while (elapsed < animationDuration / 2f)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / (animationDuration / 2f);
            target.localScale = Vector3.Lerp(targetScale, originalScale, t);
            yield return null;
        }

        target.localScale = originalScale;
    }

    #endregion

    #region üũ �޼���

    public bool HasEquipmentTickets(int amount) => equipmentTickets >= amount;
    public bool HasCompanionTickets(int amount) => companionTickets >= amount;
    public bool HasRelicTickets(int amount) => relicTickets >= amount;
    public bool HasCrystals(int amount) => crystals >= amount;
    public bool HasEssences(int amount) => essences >= amount;
    public bool HasFragments(int amount) => fragments >= amount;

    #endregion

    #region �����

    [ContextMenu("Add 100 Equipment Tickets")]
    private void DebugAddEquipmentTickets()
    {
        AddEquipmentTickets(100);
    }

    [ContextMenu("Add 100 Companion Tickets")]
    private void DebugAddCompanionTickets()
    {
        AddCompanionTickets(100);
    }

    [ContextMenu("Add 100 Relic Tickets")]
    private void DebugAddRelicTickets()
    {
        AddRelicTickets(100);
    }

    #endregion
}