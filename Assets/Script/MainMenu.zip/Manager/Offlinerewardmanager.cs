﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class OfflineRewardManager : MonoBehaviour
{
    public static OfflineRewardManager Instance { get; private set; }

    [Header("방치 보상 설정")]
    [SerializeField] private int goldPerMinute = 5;
    [SerializeField] private int expPerMinute = 3;
    [SerializeField] private int gemPerMinute = 3;  // ✅ 소문자로 통일

    [SerializeField] private float maxOfflineHours = 24f;
    [SerializeField] private float minOfflineMinutes = 1f;

    [Header("아이템 방치 보상")]
    [SerializeField] private OfflineItemReward[] offlineItemRewards;

    [Header("보상 배율")]
    [SerializeField] private float rewardMultiplier = 1.0f;
    [SerializeField] private float adBonusMultiplier = 2.0f;

    [Header("웨이브 연동")]
    [SerializeField] private float waveRewardBonusPercent = 5f;

    [Header("UI 연결")]
    [SerializeField] private GameObject offlineRewardPopupPrefab;

    private const string LAST_LOGOUT_TIME_KEY = "LastLogoutTime";
    private const string OFFLINE_GOLD_RATE_KEY = "OfflineGoldRate";
    private const string OFFLINE_EXP_RATE_KEY = "OfflineExpRate";
    private const string OFFLINE_GEM_RATE_KEY = "OfflineGemRate";  // ✅ 추가
    private const string CURRENT_WAVE_KEY = "CurrentWaveIndex";

    private OfflineRewardData lastCalculatedReward;

    public static event Action<OfflineRewardData> OnOfflineRewardCalculated;
    public static event Action<OfflineRewardData> OnOfflineRewardClaimed;

    void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else Destroy(gameObject);
    }

    void Start() => CheckOfflineReward();

    // ─────────────────────────────────────────
    public void CheckOfflineReward()
    {
        string lastLogoutStr = PlayerPrefs.GetString(LAST_LOGOUT_TIME_KEY, "");
        if (string.IsNullOrEmpty(lastLogoutStr)) { SaveLogoutTime(); return; }

        DateTime lastLogoutTime;
        if (!DateTime.TryParse(lastLogoutStr, out lastLogoutTime)) { SaveLogoutTime(); return; }

        TimeSpan offlineDuration = DateTime.Now - lastLogoutTime;
        double offlineMinutes = offlineDuration.TotalMinutes;

        Debug.Log($"[OfflineReward] 오프라인: {offlineDuration.Hours}h {offlineDuration.Minutes}m");

        if (offlineMinutes < minOfflineMinutes) return;

        double effectiveMinutes = Math.Min(offlineMinutes, maxOfflineHours * 60.0);
        OfflineRewardData reward = CalculateReward(effectiveMinutes, offlineDuration);
        lastCalculatedReward = reward;

        OnOfflineRewardCalculated?.Invoke(reward);
        ShowOfflineRewardPopup(reward);
    }

    // ─────────────────────────────────────────
    private OfflineRewardData CalculateReward(double effectiveMinutes, TimeSpan actualDuration)
    {
        OfflineRewardData reward = new OfflineRewardData();
        reward.offlineDuration = actualDuration;
        reward.effectiveMinutes = effectiveMinutes;

        int savedWave = PlayerPrefs.GetInt(CURRENT_WAVE_KEY, 0);
        float waveBonus = 1f + (savedWave * waveRewardBonusPercent / 100f);

        // ✅ 골드
        float savedGoldRate = PlayerPrefs.GetFloat(OFFLINE_GOLD_RATE_KEY, goldPerMinute);
        reward.goldReward = Mathf.RoundToInt((float)(savedGoldRate * effectiveMinutes * rewardMultiplier * waveBonus));

        // ✅ 경험치
        float savedExpRate = PlayerPrefs.GetFloat(OFFLINE_EXP_RATE_KEY, expPerMinute);
        reward.expReward = Mathf.RoundToInt((float)(savedExpRate * effectiveMinutes * rewardMultiplier * waveBonus));

        // ✅ 젬 (추가)
        float savedGemRate = PlayerPrefs.GetFloat(OFFLINE_GEM_RATE_KEY, gemPerMinute);
        reward.gemReward = Mathf.RoundToInt((float)(savedGemRate * effectiveMinutes * rewardMultiplier * waveBonus));

        reward.itemRewards = CalculateItemRewards(effectiveMinutes, waveBonus);
        reward.baseMultiplier = rewardMultiplier;
        reward.waveBonus = waveBonus;
        reward.currentWave = savedWave;

        Debug.Log($"[OfflineReward] 골드:{reward.goldReward} EXP:{reward.expReward} 젬:{reward.gemReward}");
        return reward;
    }

    private List<OfflineItemRewardResult> CalculateItemRewards(double minutes, float waveBonus)
    {
        List<OfflineItemRewardResult> results = new List<OfflineItemRewardResult>();
        if (offlineItemRewards == null) return results;

        foreach (var itemReward in offlineItemRewards)
        {
            if (itemReward.item == null) continue;
            int rollCount = Mathf.Max(1, Mathf.FloorToInt((float)(minutes / itemReward.rollIntervalMinutes)));
            int totalDropped = 0;

            for (int i = 0; i < rollCount; i++)
            {
                if (UnityEngine.Random.Range(0f, 100f) <= itemReward.dropChance * waveBonus)
                    totalDropped += UnityEngine.Random.Range(itemReward.minAmount, itemReward.maxAmount + 1);
            }

            if (totalDropped > 0)
            {
                totalDropped = Mathf.Min(totalDropped, itemReward.maxTotalPerSession);
                results.Add(new OfflineItemRewardResult { item = itemReward.item, amount = totalDropped });
            }
        }
        return results;
    }

    // ─────────────────────────────────────────
    public void ClaimReward() => ApplyReward(lastCalculatedReward, 1f);
    public void ClaimRewardWithAd() => ApplyReward(lastCalculatedReward, adBonusMultiplier);

    private void ApplyReward(OfflineRewardData reward, float bonusMultiplier)
    {
        if (reward == null) { Debug.LogWarning("[OfflineReward] 수령할 보상 없음"); return; }

        int finalGold = Mathf.RoundToInt(reward.goldReward * bonusMultiplier);
        int finalExp = Mathf.RoundToInt(reward.expReward * bonusMultiplier);
        int finalGem = Mathf.RoundToInt(reward.gemReward * bonusMultiplier);  // ✅

        if (GameManager.Instance != null)
        {
            if (finalGold > 0) GameManager.Instance.AddGold(finalGold);
            if (finalExp > 0) GameManager.Instance.AddExp(finalExp);
            if (finalGem > 0) GameManager.Instance.AddGem(finalGem);   // ✅
        }

        if (reward.itemRewards != null && InventoryManager.Instance != null)
        {
            foreach (var item in reward.itemRewards)
            {
                int finalAmount = Mathf.RoundToInt(item.amount * bonusMultiplier);
                InventoryManager.Instance.AddItem(item.item, finalAmount);
            }
        }

        string multi = bonusMultiplier > 1f ? $" (x{bonusMultiplier})" : "";
        UIManager.Instance?.ShowMessage(
            $"방치 보상 수령!{multi}\n골드:{finalGold} EXP:{finalExp} 젬:{finalGem}", Color.yellow);

        reward.appliedMultiplier = bonusMultiplier;
        OnOfflineRewardClaimed?.Invoke(reward);
        lastCalculatedReward = null;

        Debug.Log($"[OfflineReward] 수령 완료 - 골드:{finalGold} EXP:{finalExp} 젬:{finalGem} x{bonusMultiplier}");
    }

    // ─────────────────────────────────────────
    public void SaveLogoutTime()
    {
        string now = DateTime.Now.ToString("o");
        PlayerPrefs.SetString(LAST_LOGOUT_TIME_KEY, now);
        PlayerPrefs.SetFloat(OFFLINE_GOLD_RATE_KEY, goldPerMinute);
        PlayerPrefs.SetFloat(OFFLINE_EXP_RATE_KEY, expPerMinute);
        PlayerPrefs.SetFloat(OFFLINE_GEM_RATE_KEY, gemPerMinute);  // ✅

        if (WaveSpawner.Instance != null)
            PlayerPrefs.SetInt(CURRENT_WAVE_KEY, WaveSpawner.Instance.CurrentWaveIndex);

        PlayerPrefs.Save();
        Debug.Log($"[OfflineReward] 로그아웃 저장: {now}");
    }

    public void UpgradeOfflineRate(int addGold, int addExp, int addGem = 0)
    {
        goldPerMinute += addGold;
        expPerMinute += addExp;
        gemPerMinute += addGem;  // ✅
    }

    public void SetRewardMultiplier(float multiplier) => rewardMultiplier = Mathf.Max(0.1f, multiplier);

    // ✅ 젬 포함 정보 표시
    public string GetOfflineRateInfo()
    {
        int waveIndex = WaveSpawner.Instance?.CurrentWaveIndex ?? 0;
        float waveBonus = 1f + (waveIndex * waveRewardBonusPercent / 100f);

        int effGold = Mathf.RoundToInt(goldPerMinute * rewardMultiplier * waveBonus);
        int effExp = Mathf.RoundToInt(expPerMinute * rewardMultiplier * waveBonus);
        int effGem = Mathf.RoundToInt(gemPerMinute * rewardMultiplier * waveBonus);

        return $"분당 골드:{effGold} | EXP:{effExp} | 젬:{effGem}";
    }

    private void ShowOfflineRewardPopup(OfflineRewardData reward)
    {
        OfflineRewardUI existingUI = FindObjectOfType<OfflineRewardUI>(true);
        if (existingUI != null) { existingUI.ShowReward(reward); return; }

        if (offlineRewardPopupPrefab != null)
        {
            Canvas canvas = FindObjectOfType<Canvas>();
            if (canvas != null)
            {
                GameObject popup = Instantiate(offlineRewardPopupPrefab, canvas.transform);
                popup.GetComponent<OfflineRewardUI>()?.ShowReward(reward);
            }
        }
        else
        {
            Debug.LogWarning("[OfflineReward] UI 프리팹 없음 - 자동 수령");
            ClaimReward();
        }
    }

    void OnApplicationPause(bool pause)
    {
        if (pause) SaveLogoutTime();
        else CheckOfflineReward();
    }

    void OnApplicationQuit() => SaveLogoutTime();
}

#region 데이터 클래스

[System.Serializable]
public class OfflineRewardData
{
    public TimeSpan offlineDuration;
    public double effectiveMinutes;
    public int goldReward;
    public int expReward;
    public int gemReward;                              // ✅ 젬
    public List<OfflineItemRewardResult> itemRewards;
    public float baseMultiplier;
    public float waveBonus;
    public int currentWave;
    public float appliedMultiplier = 1f;

    public string GetDurationString()
    {
        if (offlineDuration.TotalHours >= 1)
            return $"{(int)offlineDuration.TotalHours}시간 {offlineDuration.Minutes}분";
        else if (offlineDuration.TotalMinutes >= 1)
            return $"{(int)offlineDuration.TotalMinutes}분";
        else
            return $"{offlineDuration.Seconds}초";
    }
}

[System.Serializable]
public class OfflineItemRewardResult
{
    public ItemData item;
    public int amount;
}

[System.Serializable]
public class OfflineItemReward
{
    public ItemData item;
    [Range(0f, 100f)] public float dropChance = 10f;
    public float rollIntervalMinutes = 10f;
    [Min(1)] public int minAmount = 1;
    [Min(1)] public int maxAmount = 1;
    public int maxTotalPerSession = 10;
}

#endregion